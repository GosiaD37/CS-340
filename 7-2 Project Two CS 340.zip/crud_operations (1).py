#!/usr/bin/env python
# coding: utf-8

# In[1]:


from pymongo import MongoClient

class AnimalShelter:
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self):
        # MongoDB connection configuration
        USER = 'aacuser'
        PASS = 'Nikispring7'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31988
        DB = 'AAC'
        COL = 'animals'

        # Initialize MongoDB connection
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    # Create method to insert a document into MongoDB
    def create(self, data):
        if data:
            self.collection.insert_one(data)  # Insert data (dictionary) into MongoDB
            return True
        else:
            raise ValueError("No data to insert")

    # Read method to query documents from MongoDB
    def read(self, query):
        results = self.collection.find(query)  # Perform the find query
        return [result for result in results]  # Return results as a list of dictionaries


# In[1]:


jupyter nbconvert --to script crud_operations.ipynb


# In[ ]:




